import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QStackedWidget
from PyQt6 import uic


class MainWindow(QMainWindow,):
    def __init__(self):
        super().__init__()
        uic.loadUi("main_window.ui", self)
        self.setWindowTitle('CRM')



app = QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()